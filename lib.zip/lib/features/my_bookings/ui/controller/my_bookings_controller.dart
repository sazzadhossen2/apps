import 'package:flutter/foundation.dart';

import '../../../../app/utils.dart';
import '../../../../core/services/api_service/api_services.dart';
import '../../../../core/services/network/network_response.dart';
import '../../models/appointment_model.dart';

class MyBookingsController extends ChangeNotifier {
  final ApiServices _api = ApiServices.instance;

  ViewState state = ViewState.idle;
  String? error;
  List<AppointmentModel> upcoming = [];
  List<AppointmentModel> past = [];
  String? cancelError;
  String? cancellingId;

  AppointmentModel? byId(String id) {
    for (final a in [...upcoming, ...past]) {
      if (a.id == id) return a;
    }
    return null;
  }

  /// [silent] keeps the current list on screen while refreshing.
  Future<void> load({bool silent = false}) async {
    if (!silent || state == ViewState.idle || state == ViewState.error) {
      state = ViewState.loading;
      notifyListeners();
    }
    final results = await Future.wait([_api.appointments(when: 'upcoming'), _api.appointments(when: 'past')]);

    if (results.every((r) => r.isSuccess)) {
      upcoming = _parse(results[0]);
      past = _parse(results[1]);
      state = ViewState.success;
      error = null;
    } else {
      error = results.firstWhere((r) => !r.isSuccess).errorMessage;
      if (state != ViewState.success) state = ViewState.error;
    }
    notifyListeners();
  }

  List<AppointmentModel> _parse(NetworkResponse res) => res.listOf('items').map(AppointmentModel.fromJson).toList();

  Future<bool> cancel(String id) async {
    cancelError = null;
    cancellingId = id;
    notifyListeners();

    final res = await _api.cancelAppointment(id);
    cancellingId = null;

    if (res.isSuccess) {
      final updated = upcoming.where((a) => a.id == id).toList();
      if (updated.isNotEmpty) {
        upcoming = upcoming.where((a) => a.id != id).toList();
        past = [updated.first.copyWith(status: AppointmentStatus.cancelled), ...past];
      }
      notifyListeners();
      return true;
    }
    cancelError = res.errorMessage;
    notifyListeners();
    return false;
  }

  /// Called on logout so the next user never sees someone else's bookings.
  void reset() {
    state = ViewState.idle;
    upcoming = [];
    past = [];
    error = null;
    notifyListeners();
  }
}

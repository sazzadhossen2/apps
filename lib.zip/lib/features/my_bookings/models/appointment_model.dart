
import '../../../app/utils.dart';
import '../../home/models/service_model.dart';

class AppointmentModel {
  final String id;
  final ServiceModel? service;
  final String serviceId;
  final DateTime startAt; // local time
  final DateTime endAt; // local time
  final String status;
  final String notes;
  final double price;
  final DateTime createdAt;

  const AppointmentModel({
    required this.id,
    required this.service,
    required this.serviceId,
    required this.startAt,
    required this.endAt,
    required this.status,
    required this.notes,
    required this.price,
    required this.createdAt,
  });

  factory AppointmentModel.fromJson(Map<String, dynamic> j) {
    final svc = j['service'];
    final hasService = svc is Map;
    return AppointmentModel(
      id: (j['id'] ?? j['_id'] ?? '').toString(),
      service: hasService ? ServiceModel.fromJson(Map<String, dynamic>.from(svc)) : null,
      serviceId: hasService ? (svc['id'] ?? svc['_id'] ?? '').toString() : (svc ?? '').toString(),
      startAt: DateTime.parse(j['startAt'].toString()).toLocal(),
      endAt: DateTime.parse(j['endAt'].toString()).toLocal(),
      status: (j['status'] ?? AppointmentStatus.pending).toString(),
      notes: (j['notes'] ?? '').toString(),
      price: (j['price'] as num?)?.toDouble() ?? 0,
      createdAt: DateTime.tryParse((j['createdAt'] ?? '').toString())?.toLocal() ?? DateTime.now(),
    );
  }

  AppointmentModel copyWith({String? status}) => AppointmentModel(
        id: id,
        service: service,
        serviceId: serviceId,
        startAt: startAt,
        endAt: endAt,
        status: status ?? this.status,
        notes: notes,
        price: price,
        createdAt: createdAt,
      );

  bool get isPending => status == AppointmentStatus.pending;
  String get serviceName => service?.name ?? 'Service';
  int get durationMinutes => endAt.difference(startAt).inMinutes;
  String get shortId => id.length > 8 ? id.substring(id.length - 8).toUpperCase() : id.toUpperCase();
}

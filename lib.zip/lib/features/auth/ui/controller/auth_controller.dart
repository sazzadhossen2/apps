import 'package:flutter/foundation.dart';


import '../../../../app/app_router.dart';
import '../../../../app/utils.dart';
import '../../../../core/services/api_service/api_services.dart';
import '../../../../core/services/network/network_response.dart';
import '../../../../core/services/session/session.dart';
import '../../models/user_model.dart';

class AuthController extends ChangeNotifier {
  final ApiServices _api = ApiServices.instance;

  UserModel? _user;
  bool _busy = false;
  String? _error;

  UserModel? get user => _user;
  bool get isBusy => _busy;
  String? get error => _error;
  bool get isLoggedIn => _user != null;

  void _setBusy(bool v) {
    _busy = v;
    notifyListeners();
  }

  /// Splash: restores a saved session. Returns true when the user is still logged in.
  Future<bool> bootstrap() async {
    await Session.instance.restore();
    if (!Session.instance.hasToken) return false;

    final res = await _api.me();
    // Handle expired sessions from now on (after the first check).
    Session.instance.onExpired = _handleExpired;

    if (res.isSuccess) {
      _user = UserModel.fromJson(Map<String, dynamic>.from(res.dataMap['user'] as Map));
      notifyListeners();
      return true;
    }
    return false;
  }

  void _handleExpired() {
    _user = null;
    notifyListeners();
    AppRouter.resetToLogin();
    AppSnack.show('Your session has expired. Please log in again.', error: true);
  }

  Future<bool> login(String email, String password) async {
    _error = null;
    _setBusy(true);
    final res = await _api.login(email.trim(), password);
    return _finishAuth(res);
  }

  Future<bool> register(String name, String email, String password) async {
    _error = null;
    _setBusy(true);
    final res = await _api.register(name.trim(), email.trim(), password);
    return _finishAuth(res);
  }

  Future<bool> _finishAuth(NetworkResponse res) async {
    if (res.isSuccess) {
      final data = res.dataMap;
      await Session.instance.start(data['token'].toString());
      _user = UserModel.fromJson(Map<String, dynamic>.from(data['user'] as Map));
      Session.instance.onExpired = _handleExpired;
      _busy = false;
      notifyListeners();
      return true;
    }
    _error = res.errorMessage;
    _setBusy(false);
    return false;
  }

  Future<bool> updateProfile({required String name, required String phone}) async {
    _error = null;
    _setBusy(true);
    final res = await _api.updateProfile(name: name.trim(), phone: phone.trim());
    if (res.isSuccess) {
      _user = UserModel.fromJson(Map<String, dynamic>.from(res.dataMap['user'] as Map));
      _busy = false;
      notifyListeners();
      return true;
    }
    _error = res.errorMessage;
    _setBusy(false);
    return false;
  }

  Future<bool> changePassword(String current, String next) async {
    _error = null;
    _setBusy(true);
    final res = await _api.changePassword(current, next);
    if (!res.isSuccess) _error = res.errorMessage;
    _setBusy(false);
    return res.isSuccess;
  }

  Future<void> logout() async {
    Session.instance.onExpired = null;
    _api.logout(); // fire and forget; the token is discarded locally anyway
    await Session.instance.end();
    _user = null;
    notifyListeners();
  }
}

import 'package:flutter/material.dart';

import '../../../../app/kcolor.dart';
import '../../../../app/kstrings.dart';
import '../../../../app/utils.dart';
import '../../../../core/services/network/network_response.dart';
import '../../../../utils/widgets/widgets.dart';
import '../../../my_bookings/models/appointment_model.dart';
import '../../../navigation_menu/ui/screens/main_shell.dart';

class BookingConfirmationScreen extends StatelessWidget {
  const BookingConfirmationScreen({super.key, required this.appointment});
  final AppointmentModel appointment;

  void _goHome(BuildContext context, int tab) {
    MainShell.tab.value = tab;
    Navigator.of(context).popUntil((route) => route.isFirst);
  }

  @override
  Widget build(BuildContext context) {
    final a = appointment;
    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (didPop, _) {
        if (!didPop) _goHome(context, 0);
      },
      child: Scaffold(
        body: SafeArea(
          child: Center(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(24),
              child: ResponsiveBody(
                child: Column(
                  children: [
                    TweenAnimationBuilder<double>(
                      tween: Tween(begin: 0, end: 1),
                      duration: const Duration(milliseconds: 650),
                      curve: Curves.elasticOut,
                      builder: (_, v, child) => Transform.scale(scale: v, child: child),
                      child: Container(
                        width: 104,
                        height: 104,
                        decoration: const BoxDecoration(shape: BoxShape.circle, gradient: LinearGradient(colors: KColors.gradient)),
                        child: const Icon(Icons.check_rounded, color: Colors.white, size: 60),
                      ),
                    ),
                    const SizedBox(height: 24),
                    KText(text: 'Booking confirmed!', fontSize: 26, fontWeight: FontWeight.w800),
                    const SizedBox(height: 8),
                    KText(
                      text: 'Your appointment request has been sent. You will see its status in My Bookings.',
                      textAlign: TextAlign.center,
                      color: KColors.textSecondary,
                      height: 1.45,
                    ),
                    const SizedBox(height: 26),
                    AppCard(
                      child: Column(
                        children: [
                          Row(
                            children: [
                              Expanded(child: KText(text: a.serviceName, fontWeight: FontWeight.w800, fontSize: 17)),
                              StatusChip(status: a.status),
                            ],
                          ),
                          const Divider(height: 24),
                          InfoRow(icon: Icons.calendar_today_rounded, label: 'Date', value: Fmt.date(a.startAt)),
                          InfoRow(icon: Icons.access_time_rounded, label: 'Time', value: '${Fmt.time(a.startAt)} – ${Fmt.time(a.endAt)}'),
                          InfoRow(icon: Icons.payments_rounded, label: 'Price', value: Fmt.price(a.price)),
                          InfoRow(icon: Icons.confirmation_number_rounded, label: 'Booking ID', value: '#${a.shortId}'),
                        ],
                      ),
                    ),
                    const SizedBox(height: 26),
                    KButton(label: 'View my bookings', icon: Icons.event_note_rounded, onPressed: () => _goHome(context, 1)),
                    const SizedBox(height: 12),
                    KButton(label: 'Back to home', type: KButtonType.outline, onPressed: () => _goHome(context, 0)),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

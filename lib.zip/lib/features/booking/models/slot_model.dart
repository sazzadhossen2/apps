class SlotModel {
  final String time; // "09:00" (business time)
  final DateTime startAtUtc;
  final DateTime endAtUtc;
  final bool available;

  const SlotModel({
    required this.time,
    required this.startAtUtc,
    required this.endAtUtc,
    required this.available,
  });

  factory SlotModel.fromJson(Map<String, dynamic> j) => SlotModel(
        time: (j['time'] ?? '').toString(),
        startAtUtc: DateTime.parse(j['startAt'].toString()).toUtc(),
        endAtUtc: DateTime.parse(j['endAt'].toString()).toUtc(),
        available: j['available'] == true,
      );

  DateTime get startLocal => startAtUtc.toLocal();
}

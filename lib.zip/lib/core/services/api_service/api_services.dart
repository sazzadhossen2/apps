
import '../../../app/urls.dart';
import '../network/network_client.dart';
import '../network/network_response.dart';

/// Every REST endpoint used by the app, in one place.
class ApiServices {
  ApiServices._();
  static final ApiServices instance = ApiServices._();

  final NetworkClient _c = NetworkClient();

  // ---- Auth ----
  Future<NetworkResponse> login(String email, String password) =>
      _c.request('POST', Urls.login, body: {'email': email, 'password': password}, auth: false);

  Future<NetworkResponse> register(String name, String email, String password) => _c.request(
        'POST',
        Urls.register,
        body: {'name': name, 'email': email, 'password': password},
        auth: false,
      );

  Future<NetworkResponse> logout() => _c.request('POST', Urls.logout);

  // ---- User ----
  Future<NetworkResponse> me() => _c.request('GET', Urls.me);

  Future<NetworkResponse> updateProfile({required String name, required String phone}) =>
      _c.request('PUT', Urls.me, body: {'name': name, 'phone': phone});

  Future<NetworkResponse> changePassword(String current, String next) => _c.request(
        'PUT',
        Urls.changePassword,
        body: {'currentPassword': current, 'newPassword': next},
      );

  // ---- Services ----
  Future<NetworkResponse> services({
    String? search,
    String? category,
    String? sort,
    double? minPrice,
    double? maxPrice,
    bool featuredOnly = false,
    int limit = 50,
  }) =>
      _c.request('GET', Urls.services, query: {
        'search': search,
        'category': category,
        'sort': sort,
        'minPrice': minPrice?.round(),
        'maxPrice': maxPrice?.round(),
        'featured': featuredOnly ? 'true' : null,
        'limit': limit,
      });

  Future<NetworkResponse> categories() => _c.request('GET', Urls.categories);

  Future<NetworkResponse> serviceById(String id) => _c.request('GET', Urls.service(id));

  Future<NetworkResponse> availability(String serviceId, String date) =>
      _c.request('GET', Urls.availability(serviceId), query: {'date': date});

  // ---- Appointments ----
  Future<NetworkResponse> createAppointment({
    required String serviceId,
    required String startAtIso,
    String notes = '',
  }) =>
      _c.request('POST', Urls.appointments, body: {
        'serviceId': serviceId,
        'startAt': startAtIso,
        if (notes.trim().isNotEmpty) 'notes': notes.trim(),
      });

  Future<NetworkResponse> appointments({required String when}) =>
      _c.request('GET', Urls.appointments, query: {'when': when});

  Future<NetworkResponse> appointmentById(String id) => _c.request('GET', Urls.appointment(id));

  Future<NetworkResponse> cancelAppointment(String id) => _c.request('PATCH', Urls.cancelAppointment(id));

  // ---- AI ----
  Future<NetworkResponse> aiChat(String message, List<Map<String, String>> history) =>
      _c.request('POST', Urls.aiChat, body: {'message': message, 'history': history});
}

class Urls {
  Urls._();

  /// Override at build time:
  /// flutter run --dart-define=API_BASE_URL=http://192.168.0.10:5000/api/v1
  /// 10.0.2.2 is the host machine as seen from the Android emulator.
  static const String baseUrl = String.fromEnvironment(
    'http://localhost:5000/api/v1',
    defaultValue: 'http://localhost:5000/api/v1',
  );

  // Auth
  static const String register = '/auth/register';
  static const String login = '/auth/login';
  static const String logout = '/auth/logout';

  // User
  static const String me = '/users/me';
  static const String changePassword = '/users/me/password';

  // Services
  static const String services = '/services';
  static const String categories = '/services/categories';
  static String service(String id) => '/services/$id';
  static String availability(String id) => '/services/$id/availability';

  // Appointments
  static const String appointments = '/appointments';
  static String appointment(String id) => '/appointments/$id';
  static String cancelAppointment(String id) => '/appointments/$id/cancel';

  // AI
  static const String aiChat = '/ai/chat';
}

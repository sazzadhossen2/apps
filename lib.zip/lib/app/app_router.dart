import 'package:flutter/material.dart';


import '../features/auth/ui/screens/login_screen.dart';
import '../features/navigation_menu/ui/screens/main_shell.dart';

final GlobalKey<NavigatorState> navigatorKey = GlobalKey<NavigatorState>();

/// Navigation that must work without a BuildContext (e.g. when the session expires).
class AppRouter {
  AppRouter._();

  static void resetToLogin() {
    navigatorKey.currentState?.pushAndRemoveUntil(
      MaterialPageRoute(builder: (_) => const LoginScreen()),
      (_) => false,
    );
  }

  static void resetToHome() {
    MainShell.tab.value = 0;
    navigatorKey.currentState?.pushAndRemoveUntil(
      MaterialPageRoute(builder: (_) => const MainShell()),
      (_) => false,
    );
  }
}
